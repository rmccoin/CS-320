package test;

import org.junit.jupiter.api.Test;

import main.ContactService;
import main.Contact;

import static org.junit.jupiter.api.Assertions.*;

// Test class for ContactService methods
public class ContactServiceTest {

    // method to test add a contact
    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("0123456789", "Larry", "Smith", "0123456789", "123 Gravel Rd");
        contactService.addContact(contact);
        
        // Assert that the added contact is retrievable
        assertEquals(contact, contactService.getContact("0123456789"));
    }

    // method to test delete a contact
    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("0123456789", "Larry", "Smith", "0123456789", "123 Gravel Rd");
        contactService.addContact(contact);
        contactService.deleteContact("0123456789");

        // Assert that the deleted contact is no longer retrievable
        assertNull(contactService.getContact("0123456789"));
    }

    // method to test update the first name of a contact
    @Test
    public void testUpdateFirstName() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("0123456789", "Larry", "Smith", "0123456789", "123 Gravel Rd");
        contactService.addContact(contact);
        contactService.updateFirstName("0123456789", "Bob");

        // Assert that the first name is updated correctly
        assertEquals("Bob", contactService.getContact("0123456789").getFirstName());
    }

    // method to test update the last name of a contact
    @Test
    public void testUpdateLastName() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("0123456789", "Larry", "Smith", "0123456789", "123 Gravel Rd");
        contactService.addContact(contact);
        contactService.updateLastName("0123456789", "Hall");

        // Assert that the last name is updated correctly
        assertEquals("Hall", contactService.getContact("0123456789").getLastName());
    }

    // method to test update the phone number of a contact
    @Test
    public void testUpdatePhone() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("0123456789", "Larry", "Smith", "0123456789", "123 Gravel Rd");
        contactService.addContact(contact);
        contactService.updatePhone("0123456789", "9876543210");

        // Assert that the phone number is updated correctly
        assertEquals("9876543210", contactService.getContact("0123456789").getPhone());
    }

    // method to test update the address of a contact
    @Test
    public void testUpdateAddress() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("0123456789", "Larry", "Smith", "0123456789", "123 Gravel Rd");
        contactService.addContact(contact);
        contactService.updateAddress("0123456789", "123 City Ln");

        // check to see if the address is updated correctly
        assertEquals("456 Elm St", contactService.getContact("0123456789").getAddress());
    }
}