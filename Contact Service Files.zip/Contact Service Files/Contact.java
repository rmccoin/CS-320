package main;
//define contact class
public class Contact {

	// private variables in the contact class 
	String contactID;
	String firstName;
	String lastName; 
	String phone;
	String address;

	
	// public constructor that initializes the contact details
	public Contact(String contactID, String firstName, 
			String lastName, String phone, String address) {
		this.contactID = contactID;
		this.firstName = firstName; 
		this.lastName = lastName; 
		this.phone = phone; 
		this.address = address;
	}
	
	
	//public string, method to get the contactID
	public String getContactID() {
		return contactID;
	}
	
	//public string, method to get the firstName
	public String getFirstName() {
		return firstName;
	}

	//public string, method to get the lastName
	public String getLastName() {
		return lastName;
	}
	
	//public string, method to get the phone
	public String getPhone() {
		return phone;
	}
	
	//public string, method to get the address
	public String getAddress() {
		return address;
	}


}
