package main;
import java.util.HashMap;
import java.util.Map;

// define ContactService class 
public class ContactService {
	
	// private map that stores the contacts
    private Map<String, Contact> contacts;

    // public constructor that initializes the contacts map
    public ContactService() {
        contacts = new HashMap<>();
    }

    // public method that adds a contact to the map
    public void addContact(Contact contact) {
        contacts.put(contact.getContactID(), contact);
    }

    // public method that deletes a contact from the map
    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    // public method that updates the first name for a contact
    public void updateFirstName(String contactID, String newFirstName) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.firstName = newFirstName;
        }
    }

    //public method that updates the last name for a contact  
    public void updateLastName(String contactID, String newLastName) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.lastName = newLastName;
        }
    }

    // public method that updates the phone for a contact 
    public void updatePhone(String contactID, String newPhone) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.phone = newPhone;
        }
    }

    // public method that updates the address for a contact 
    public void updateAddress(String contactID, String newAddress) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.address = newAddress;
        }
    }

    // method that uses the ID to get a contact 
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}
