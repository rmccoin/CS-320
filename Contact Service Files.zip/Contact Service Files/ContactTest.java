package test;

import org.junit.jupiter.api.Test;

import main.Contact;

import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

// define class for ContactTest 
public class ContactTest {
    
    
	@Test
	@DisplayName("Contact ID cannot have more than 10 characters")
	void testContactIDWithMoreThanTenCharacters() {
		Contact contact = new Contact("12345678912", "firstName", "lastName", "phone", "address");
		if (contact.getContactID().length() > 10) {
			fail("Contact ID has more than 10 characters.");
		}
	}

	@Test
	@DisplayName("Contact First Name cannot have more than 10 characters")
	void testContactFirstNameWithMoreThanTenCharacters() {
		Contact contact = new Contact("contactID", "MrAlexander", "lastName", "phone", "address");
		if (contact.getFirstName().length() > 10) {
			fail("First Name has more than 10 characters.");
		}
	}

	@Test
	@DisplayName("Contact Last Name cannot have more than 10 characters")
	void testContactLastNameWithMoreThanTenCharacters() {
		Contact contact = new Contact("contactID", "firstName", "HuckleberryFinn", "phone", "address");
		if (contact.getLastName().length() > 10) {
			fail("Last Name has more than 10 characters.");
		}
	}

	@Test
	@DisplayName("Contact phone number is exactly 10 characters")
	void testContactNumberWithMoreThanTenCharacters() {
		Contact contact = new Contact("contactID", "firstName", "lastName", "12345678912", "address");
		if (contact.getPhone().length() != 10) {
			fail("Phone number length does not equal 10.");
		}
	}

	@Test
	@DisplayName("Contact address cannot have more than 30 characters")
	void testContactAddressWithMoreThanThirtyCharacters() {
		Contact contact = new Contact("contactID", "firstName", "lastName", "phone",
				"123456789 is nine characters long" + "123456789 is another nine characters long");
		if (contact.getAddress().length() > 30) {
			fail("Address has more than 30 characters.");
		}
	}
	
	@Test
	@DisplayName("Contact First Name shall not be null")
	void testContactContactIDNotNull() {
		Contact contact = new Contact("null", "firstName", "lastName", "phone", "address");
		assertNotNull(contact.getContactID(), "Contact ID was null.");
	}

	@Test
	@DisplayName("Contact First Name shall not be null")
	void testContactFirstNameNotNull() {
		Contact contact = new Contact("contactID", null, "lastName", "phone", "address");
		assertNotNull(contact.getFirstName(), "First name was null.");
	}

	@Test
	@DisplayName("Contact Last Name shall not be null")
	void testContactLastNameNotNull() {
		Contact contact = new Contact("contactID", "firstName", null, "phone", "address");
		assertNotNull(contact.getLastName(), "Last name was null.");
	}

	@Test
	@DisplayName("Contact Phone Number shall not be null")
	void testContactPhoneNotNull() {
		Contact contact = new Contact("contactID", "firstName", "lastName", null, "address");
		assertNotNull(contact.getPhone(), "Phone number was null.");
	}

	@Test
	@DisplayName("Contact Address shall not be null")
	void testContactAddressNotNull() {
		Contact contact = new Contact("contactID", "firstName", "lastName", "phone", null);
		assertNotNull(contact.getAddress(), "Address was null.");
	}
    
}

